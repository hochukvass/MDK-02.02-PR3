This is Sql Database connector which can connect database and maintain connection pooling.
This package allow to connect multiple database operations.

Install Nuget package 'System.Data.SqlClient 4.8.5' in your application.
Add file 'AFDataAccessor.json' in your project if it is web application. Make sure this file is in current directory.